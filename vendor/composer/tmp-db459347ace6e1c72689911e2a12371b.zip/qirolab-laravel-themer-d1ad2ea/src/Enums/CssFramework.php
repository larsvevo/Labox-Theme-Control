<?php

namespace Qirolab\Theme\Enums;

class CssFramework
{
    const Bootstrap = 'Bootstrap';
    const Tailwind = 'Tailwind';
}
