<?php

namespace Qirolab\Theme\Enums;

class JsFramework
{
    const Vue3 = 'Vue 3';
    const React = 'React';
}
